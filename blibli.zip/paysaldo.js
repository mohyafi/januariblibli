const blibli = require("./helper/blibli");
const fetch = require("node-fetch");
const { v4: uuidv4 } = require("uuid");
const readline = require("readline-sync");
const fs = require("fs-extra");
const delay = require("delay");
const chalk = require("chalk");
const imaps = require("imap-simple");
const { convert } = require("html-to-text");
const { READ_MAIL_CONFIG } = require("./config");
const randstr = (length) =>
  new Promise((resolve, reject) => {
    var text = "";
    var possible = "1234567890";

    for (var i = 0; i < length; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    resolve(text);
  });

(async () => {
  const dataakun = fs.readFileSync("saldo.txt", "utf8").split("\r\n");
  for (let i in dataakun) {
    console.log(chalk.yellowBright(`[ INFO ] `) + "Data Account " + `[${i}]`);
    await delay(2000);
    const email = dataakun[i].split("|")[0];
    const password = dataakun[i].split("|")[1];
    const UserId = uuidv4();
    const Session = uuidv4();
    const RequestID = uuidv4();
    const DfToken = await randstr(43);
    const request = new blibli(UserId, Session, RequestID, DfToken);
    console.log(
      chalk.yellowBright(`[ INFO ] `) + chalk.blueBright("Email " + email)
    );
    const Login = await request.Login(email, password);
    const ParseLogin = JSON.stringify(Login);
    if (
      ParseLogin.includes(
        "login using new device is detected, please do challenge otp"
      )
    ) {
      const chalenge = Login.data.challenge.token;
      const MemanggilOtp = await request.RequestOTP(chalenge);
      if (MemanggilOtp.status === "OK") {
        console.log(
          chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("OTP Dikirim")
        );
        await delay(4000);
        const connection = await imaps.connect(READ_MAIL_CONFIG);
        // console.log("CONNECTION SUCCESSFUL", new Date().toString());
        const box = await connection.openBox("INBOX");
        const searchCriteria = ["ALL", ["TO", email]];
        const fetchOptions = {
          bodies: ["HEADER", "TEXT"],
          markSeen: false,
        };
        let results;
        let validasiemailotp;
        do {
          results = await connection.search(searchCriteria, fetchOptions);
          //   console.log(results);
          validasiemailotp = JSON.stringify(results);
        } while (!validasiemailotp.includes("attributes"));
        // console.log(results[0]["parts"][1]["body"]);
        // results.forEach((res) => {
        //   const text = res.parts.filter((part) => {
        //     return part.which === "TEXT";
        //   });
        //   let emailHTML = text[0].body;
        let emailText = convert(results[0]["parts"][1]["body"]);
        // console.log(emailText);
        const parsing = emailText.split("Kode verifikasi: ")[1];
        const babi = parsing.split("<=")[0];
        const jancok = babi.replace(/\D/gm, "");
        const otpnew = jancok;
        // });
        connection.end();
        console.log(
          chalk.yellowBright(`[ INFO ] `) +
            chalk.greenBright("OTP DETECT " + otpnew)
        );
        const otp = otpnew;
        const verify = await request.RegisLogin(email, otp, chalenge);
        if (verify.access_token) {
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright("Login Succesfully")
          );
          const Token = verify.access_token;
          const dataAccount = await request.CeckStatusAccount(Token);
          const saldo = dataAccount.data.wallet.balance;
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright("Saldo Account [ " + saldo + " ]")
          );
          const Cart = await request.DeleteCartDigital(Token);
          if (Cart.status === "OK") {
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.greenBright("Try Add Cart ")
            );
            const dataakun = fs
              .readFileSync("listkode.txt", "utf8")
              .split("\r\n");
            const PaperId = dataakun[i];
            if (PaperId === undefined) {
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.yellowBright("Kode PaperId Tidak Tersedia")
              );
              break;
            }
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.yellowBright("Kode PaperId [ " + PaperId + " ]")
            );
            const Checkout = await request.InputIdPaper(Token, PaperId);
            if (Checkout.status === "OK") {
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.greenBright("Try Check Add Cart ")
              );
              const CekCheckout = await request.CekCartDigital(Token);
              if (CekCheckout.status === "OK") {
                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.greenBright("Get Payment ")
                );

                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.greenBright(
                      "Payment Processing Cek You Account Jenius "
                    )
                );
                const Pay = await request.PaymentWallet(Token);
                if (Pay.status === "OK") {
                  const Final = await request.PaymentFinalQRIS(Token);
                  const IdPesnanan = Final.data.orderId;
                  const ApplyPin = await request.PaymentWalletPin(
                    Token,
                    IdPesnanan,
                    "112233"
                  );
                  //   console.log(ApplyPin);
                  let CekPesananStatus;
                  let Validasi;
                  do {
                    CekPesananStatus = await request.CekStatusPesanan(
                      Token,
                      IdPesnanan
                    );
                    Validasi = JSON.stringify(CekPesananStatus);
                    await delay(3000);
                    console.log(
                      chalk.yellowBright(`[ INFO ] `) +
                        chalk.redBright("Tagihan Belum Dibayar")
                    );
                  } while (!Validasi.includes("TRANSACTION_SUCCESS"));
                  console.log(
                    chalk.yellowBright(`[ INFO ] `) +
                      chalk.greenBright(
                        "Status [ " +
                          CekPesananStatus.data[0].transactionStatus +
                          " ]"
                      )
                  );
                } else {
                  console.log(Pay);
                }
              } else {
                console.log(CekCheckout);
              }
            } else {
              console.log(Checkout);
            }
          } else {
            console.log(Cart);
          }
        } else {
          console.log(chalk.redBright("Login Gagal"));
        }
      } else {
        console.log(chalk.redBright("Gagal Kirim OTP "));
      }
    } else {
      console.log(chalk.redBright(ParseLogin));
    }
    console.log("");
    await delay(5000);
  }
})();
