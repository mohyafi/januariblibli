const blibli = require("./helper/blibli");
const SMSActivate = require("./helper/index");
const fetch = require("node-fetch");
const { v4: uuidv4 } = require("uuid");
const readline = require("readline-sync");
const fs = require("fs-extra");
const delay = require("delay");
const chalk = require("chalk");
const imaps = require("imap-simple");
const { convert } = require("html-to-text");
const { READ_MAIL_CONFIG } = require("./config");
var sleep = require("delay");
const randstr = (length) =>
  new Promise((resolve, reject) => {
    var text = "";
    var possible = "1234567890";

    for (var i = 0; i < length; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    resolve(text);
  });
const nama = () =>
  new Promise((resolve, reject) => {
    fetch(
      "https://hiyaa.site/data.php?qty=1&apikey=d47d9a94-110f-4672-8851-8b749e0c7e3e",
      {
        method: "GET",
      }
    )
      .then((res) => res.json())
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
(async () => {
  const numberAdd = readline.question(
    chalk.yellowBright(`[ INFO ] `) + "Verify Number Otomatis [ y/t ] : "
  );
  const ShakeAnswers = readline.question(
    chalk.yellowBright(`[ INFO ] `) + "Claim Event Shake  [ y/t ] : "
  );
  const dataakun = fs.readFileSync("listcreate.txt", "utf8").split("\r\n");
  for (let i in dataakun) {
    await delay(2000);
    const email = dataakun[i].split("|")[0];
    const password = dataakun[i].split("|")[1];
    const UserId = uuidv4();
    const Session = uuidv4();
    const RequestID = uuidv4();
    const DfToken = await randstr(43);
    const request = new blibli(UserId, Session, RequestID, DfToken);
    const indoName = await nama();
    const { result } = indoName;
    const name =
      result[0].firstname.toLowerCase() + result[0].lastname.toLowerCase();
    console.log(
      chalk.yellowBright(`[ INFO ] `) + chalk.blueBright("Email " + email)
    );
    const Register = await request.RegisterRequestOTP(email, password, name);
    if (Register.result === "true") {
      console.log(
        chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("Try To Register ")
      );
      const chalenge = Register.resultData.challengeToken;
      const MemanggilOtp = await request.RequestOTP(chalenge);
      if (MemanggilOtp.status === "OK") {
        console.log(
          chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("Otp Terkirim")
        );
        await delay(4000);
        const connection = await imaps.connect(READ_MAIL_CONFIG);
        // console.log("CONNECTION SUCCESSFUL", new Date().toString());
        const box = await connection.openBox("INBOX");
        const searchCriteria = ["ALL", ["TO", email]];
        const fetchOptions = {
          bodies: ["HEADER", "TEXT"],
          markSeen: false,
        };
        let results;
        let validasiemailotp;
        do {
          results = await connection.search(searchCriteria, fetchOptions);
          //   console.log(results);
          validasiemailotp = JSON.stringify(results);
        } while (!validasiemailotp.includes("attributes"));
        // console.log(results[0]["parts"][1]["body"]);
        // results.forEach((res) => {
        //   const text = res.parts.filter((part) => {
        //     return part.which === "TEXT";
        //   });
        //   let emailHTML = text[0].body;
        let emailText = convert(results[0]["parts"][1]["body"]);
        const parsing = emailText
          .split("untuk akun kamu. ")[1]
          .split("<= /strong> Masukkan")[0];
        const otpnew = parsing;
        // });
        connection.end();
        console.log(
          chalk.yellowBright(`[ INFO ] `) +
            chalk.greenBright("OTP DETECT " + otpnew)
        );
        const verify = await request.RegisLogin(email, otpnew, chalenge);
        if (verify.access_token) {
          const Token = verify.access_token;
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright("Create Succesfully")
          );
          if (numberAdd === "Y" || numberAdd === "y") {
            const sms = new SMSActivate(
              "160774Ua7caa4ba037ca3fa1b5c532db607bdf8",
              "smshub"
            );
            const balance = await sms.getBalance();
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.greenBright(`Saldo SMSHUB ${balance} руб`)
            );

            let data;
            try {
              data = await sms.getNumber("fk", 6, "axis");
            } catch (err) {
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.redBright(`Gagal Mendapatkan Nomer ${err}`)
              );
              await sleep(5000);
              continue;
            }
            let { id, number } = data;
            await sms.setStatus(id, 1);
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.greenBright(`Try To Create With Number [ ${number} ]`)
            );
            const AddPhone = await request.AddNumber(Token, number);
            if (AddPhone.result === "true") {
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.greenBright("Request OTP Phone ")
              );
              let otpCode;
              let count = 0;
              do {
                otpCode = await sms.getCode(id);
                // console.log(otpCode);
                if (count === 360) {
                  await sms.setStatus(id, 8);
                }
                await sleep(1000);
                count++;
                // console.log(otpCode);
              } while (otpCode === "STATUS_WAIT_CODE");
              if (otpCode === "STATUS_CANCEL") {
                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.redBright("Cancel Phone Number")
                );
                continue;
              } else {
                const otp = otpCode;
                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.greenBright("SMS OTP : " + otp)
                );
              }
              const VerifyNumber = await request.VerifyOtpNumber(
                Token,
                otpCode
              );
              if (VerifyNumber.result === "true") {
                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.greenBright("Succesfully Add Number")
                );
                await sms.setStatus(id, 3);
                await delay(3000);
                const PinAdd = await request.AddPin(Token, "312001");
                if (PinAdd.status === "OK") {
                  const requestotp = await request.RequestOtpPin(Token);
                  console.log(
                    chalk.yellowBright(`[ INFO ] `) +
                      chalk.greenBright("Try To Request Otp Pin")
                  );
                  if (requestotp.status === "OK") {
                    let otpCode1;
                    let count1 = 0;
                    do {
                      otpCode1 = await sms.getCode(id);
                      if (count1 === 360) {
                        await sms.setStatus(id, 8);
                      }
                      await sleep(1000);
                      count1++;
                      // console.log(otpCode);
                    } while (otpCode1 === "STATUS_WAIT_CODE");
                    if (otpCode1 === "STATUS_CANCEL") {
                      console.log(
                        chalk.yellowBright(`[ INFO ] `) +
                          chalk.redBright("Cancel Phone Number")
                      );
                      continue;
                    } else {
                      const otp = otpCode1;
                      console.log(
                        chalk.yellowBright(`[ INFO ] `) +
                          chalk.greenBright("SMS PIN : " + otp)
                      );
                    }
                    const VeriyfOtpPin = await request.VerifyOtpPin(
                      Token,
                      otpCode1
                    );
                    if (VeriyfOtpPin.status === "OK") {
                      console.log(
                        chalk.yellowBright(`[ INFO ] `) +
                          chalk.greenBright("Set Pin  Succesfully")
                      );
                      if (ShakeAnswers === "y" || ShakeAnswers === "Y") {
                        const Redem = await request.Shake(
                          Token,
                          "63a5575c04ae286e540dab0f"
                        );
                        console.log(Redem);
                      } else {
                      }
                    } else {
                      console.log(
                        chalk.yellowBright(`[ INFO ] `) +
                          chalk.redBright("Set Pin Not Succesfully")
                      );
                    }
                  } else {
                    console.log(
                      chalk.yellowBright(`[ INFO ] `) +
                        chalk.redBright("Request Pin Not Succesfully")
                    );
                  }
                } else {
                  console.log(
                    chalk.yellowBright(`[ INFO ] `) +
                      chalk.redBright("Add Pin not Sucesfully")
                  );
                }
              } else {
                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.redBright("Otp Not Succesfully")
                );
              }
            } else {
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.redBright("Request Not Succesfully")
              );
            }
          } else {
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.redBright("Not Verify Phone")
            );
          }
        } else {
          console.log(
            chalk.yellowBright(`[ INFO ] `) + chalk.redBright("Create Gagal")
          );
        }
      } else {
        console.log(
          chalk.yellowBright(`[ INFO ] `) + chalk.redBright("Gagal Kirim Otp")
        );
      }
    } else {
      console.log(
        chalk.yellowBright(`[ INFO ] `) +
          chalk.redBright("Register Not Succesfully")
      );
    }
    console.log("");
  }
})();
