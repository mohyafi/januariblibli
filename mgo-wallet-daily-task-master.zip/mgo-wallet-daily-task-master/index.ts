import fetch from "node-fetch";
import { jwtDecode } from "jwt-decode";
import { Ed25519Keypair } from "@mgonetwork/mango.js/keypairs/ed25519";
import {
  decodeMgoPrivateKey,
  LEGACY_PRIVATE_KEY_SIZE,
  PRIVATE_KEY_SIZE,
} from "./mgo_sdk/typescript/src/cryptography/keypair.js";
import accounts from "./accounts.json";
import chalk from "chalk";

interface JwtPayload {
  ID: number;
  Address: string;
  SourceId: number;
  BufferTime: number;
  iss: string;
  aud: string[];
  exp: number;
  nbf: number;
}

const API_URL = "https://task-api.testnet.mangonetwork.io";

const httpRequest = async (
  url: string,
  method: string,
  headers: Record<string, string>,
  body: Record<string, any> | null = null
) => {
  try {
    const response = await fetch(url, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null,
    });

    if (!response.ok) {
      const errorBody = await response.json();
      throw new Error(
        `HTTP Error: ${response.status} ${response.statusText} - ${JSON.stringify(errorBody)}`
      );
    }

    return response.json();
  } catch (error) {
    throw error;
  }
};

const loginToMgo = async (signature: string, address: string): Promise<string> => {
  const response: any = await httpRequest(
    `${API_URL}/mgoUser/loginMgoUserPublic`,
    "POST",
    {
      accept: "*/*",
      "content-type": "application/json;charset=utf-8",
    },
    {
      signData: signature,
      address,
    }
  );
  return response.data.token;
};

const validateJwt = async (token: string): Promise<void> => {
  await httpRequest(`${API_URL}/mgoUser/getMgoUser`, "GET", {
    accept: "*/*",
    "mgo-token": token,
  });
};

const doSign = async (token: string): Promise<void> => {
  try {
    const response = await httpRequest(`${API_URL}/base/doSign`, "POST", {
      accept: "*/*",
      "content-type": "application/json;charset=utf-8",
      "mgo-token": token,
    });
    console.log(chalk.green("Sign successful:"), response);
  } catch (error: any) {
    if (error.message.includes("Please do not sign in again")) {
      console.warn(chalk.yellow("Sign already completed for today. Skipping..."));
    } else {
      throw error;
    }
  }
};

const processAccount = async (privateKey: string, index: number) => {
  const decoded = decodeMgoPrivateKey(privateKey);
  let pureSecretKey = decoded.secretKey;

  if (decoded.secretKey.length === LEGACY_PRIVATE_KEY_SIZE) {
    pureSecretKey = decoded.secretKey.slice(0, PRIVATE_KEY_SIZE);
  }

  const keyPair = Ed25519Keypair.fromSecretKey(pureSecretKey);
  const mgoAddress = keyPair.toMgoAddress();

  let token: string | null = null;
  let taskCompleted = false;

  const executeDailyTasks = async () => {
    try {
      console.log(chalk.blue.bold(`\nProcessing account #${index + 1}: ${mgoAddress}`));
      if (!token) {
        const signatureResult = await keyPair.signPersonalMessage(
          Buffer.from(
            JSON.stringify({
              address: mgoAddress,
              time: new Date().toISOString().split("T")[0],
              signType: "Login",
            })
          )
        );

        token = await loginToMgo(signatureResult.signature, mgoAddress);
        console.log(chalk.green(`New token generated for ${mgoAddress}: ${token}`));
      }

      const { exp } = jwtDecode<JwtPayload>(token);
      const currentTime = Math.floor(Date.now() / 1000);

      if (currentTime >= exp) {
        token = null;
        throw new Error("JWT expired, generating a new one.");
      }

      await validateJwt(token);
      console.log(chalk.cyan(`JWT is valid for ${mgoAddress}.`));
      await doSign(token);
      taskCompleted = true;
    } catch (error: any) {
      console.error(chalk.red(`Error during daily task for ${mgoAddress}:`), error);

      if (error.code === 'ECONNREFUSED') {
        console.warn(chalk.yellow(`Retrying task for ${mgoAddress} in 1 minute...`));
        setTimeout(executeDailyTasks, 60000); // Retry after 1 minute
        return;
      }

      token = null;
    }

    if (!taskCompleted) {
      console.warn(chalk.yellow(`Task not completed for ${mgoAddress}. Retrying in 1 minute.`));
      setTimeout(executeDailyTasks, 60000); // Retry within the same day
    } else {
      console.log(chalk.green(`Task completed for ${mgoAddress}.`));
    }
  };

  executeDailyTasks();
};

const main = async () => {
  accounts.forEach((account, index) => {
    processAccount(account.privateKey, index);
  });
};

main().catch((error) => console.error(chalk.red("Error in main function:"), error.message));
