import { TransactionBlock } from '../builder/index.js';
import type { MgoClient } from '../client/index.js';
import type { JsonRpcProvider } from '../providers/json-rpc-provider.js';
import { getObjectReference } from '../types/index.js';
import { normalizeMgoObjectId } from '../utils/mgo-types';
import { MGO_SYSTEM_ADDRESS } from './framework.js';

/**
 * Address of the Mgo System object.
 * Always the same in every Mgo network (local, devnet, testnet).
 */
export const MGO_SYSTEM_STATE_OBJECT_ID: string = normalizeMgoObjectId('0x5');

export const MGO_SYSTEM_MODULE_NAME = 'mgo_system';
export const ADD_STAKE_FUN_NAME = 'request_add_stake';
export const ADD_STAKE_LOCKED_COIN_FUN_NAME = 'request_add_stake_with_locked_coin';
export const WITHDRAW_STAKE_FUN_NAME = 'request_withdraw_stake';

/**
 * Utility class for `0x5` object
 */
export class MgoSystemStateUtil {
	/**
	 * Create a new transaction for staking coins ready to be signed and executed with `signer-and-provider`.
	 *
	 * @param coins the coins to be staked
	 * @param amount the amount to stake
	 * @param gasBudget omittable only for DevInspect mode
	 */
	public static async newRequestAddStakeTxn(
		client: JsonRpcProvider | MgoClient,
		coins: string[],
		amount: bigint,
		validatorAddress: string,
	): Promise<TransactionBlock> {
		// TODO: validate coin types and handle locked coins
		const tx = new TransactionBlock();

		const coin = tx.splitCoins(tx.gas, [tx.pure(amount)]);
		tx.moveCall({
			target: `${MGO_SYSTEM_ADDRESS}::${MGO_SYSTEM_MODULE_NAME}::${ADD_STAKE_FUN_NAME}`,
			arguments: [tx.object(MGO_SYSTEM_STATE_OBJECT_ID), coin, tx.pure(validatorAddress)],
		});
		const coinObjects = await client.multiGetObjects({
			ids: coins,
			options: {
				showOwner: true,
			},
		});
		tx.setGasPayment(coinObjects.map((obj) => getObjectReference(obj)!));
		return tx;
	}

	/**
	 * Create a new transaction for withdrawing coins ready to be signed and
	 * executed with `signer-and-provider`.
	 *
	 * @param stake the stake object created in the requestAddStake txn
	 * @param stakedCoinId the coins to withdraw
	 * @param gasBudget omittable only for DevInspect mode
	 */
	public static async newRequestWithdrawlStakeTxn(
		stake: string,
		stakedCoinId: string,
	): Promise<TransactionBlock> {
		const tx = new TransactionBlock();
		tx.moveCall({
			target: `${MGO_SYSTEM_ADDRESS}::${MGO_SYSTEM_MODULE_NAME}::${WITHDRAW_STAKE_FUN_NAME}`,
			arguments: [tx.object(MGO_SYSTEM_STATE_OBJECT_ID), tx.object(stake), tx.object(stakedCoinId)],
		});

		return tx;
	}
}
