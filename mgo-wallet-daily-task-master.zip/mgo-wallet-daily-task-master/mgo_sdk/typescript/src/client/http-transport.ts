import { Client, HTTPTransport, RequestManager } from '@open-rpc/client-js';

import type { WebsocketClientOptions } from '../rpc/websocket-client.js';
import { WebsocketClient } from '../rpc/websocket-client.js';
import { PACKAGE_VERSION, TARGETED_RPC_VERSION } from '../version.js';

/**
 * An object defining headers to be passed to the RPC server
 */
export type HttpHeaders = { [header: string]: string };

interface MgoHTTPTransportOptions {
	url: string;
	rpc?: {
		headers?: HttpHeaders;
		url?: string;
	};
	websocket?: WebsocketClientOptions & {
		url?: string;
	};
}

export interface MgoTransportRequestOptions {
	method: string;
	params: unknown[];
}

// eslint-disable-next-line @typescript-eslint/ban-types

export interface MgoTransportSubscribeOptions<T> {
	method: string;
	unsubscribe: string;
	params: unknown[];
	onMessage: (event: T) => void;
}

export interface MgoTransport {
	request<T = unknown>(input: MgoTransportRequestOptions): Promise<T>;
	subscribe<T = unknown>(input: MgoTransportSubscribeOptions<T>): Promise<() => Promise<boolean>>;
}

export class MgoHTTPTransport implements MgoTransport {
	private rpcClient: Client;
	private websocketClient: WebsocketClient;

	constructor({
		url,
		websocket: { url: websocketUrl, ...websocketOptions } = {},
		rpc,
	}: MgoHTTPTransportOptions) {
		const transport = new HTTPTransport(rpc?.url ?? url, {
			headers: {
				'Content-Type': 'application/json',
				'Client-Sdk-Type': 'typescript',
				'Client-Sdk-Version': PACKAGE_VERSION,
				'Client-Target-Api-Version': TARGETED_RPC_VERSION,
				...rpc?.headers,
			},
		});

		this.rpcClient = new Client(new RequestManager([transport]));
		this.websocketClient = new WebsocketClient(websocketUrl ?? url, websocketOptions);
	}

	async request<T>(input: MgoTransportRequestOptions): Promise<T> {
		return await this.rpcClient.request(input);
	}

	async subscribe<T>(input: MgoTransportSubscribeOptions<T>): Promise<() => Promise<boolean>> {
		const unsubscribe = await this.websocketClient.request(input);

		return async () => !!(await unsubscribe());
	}
}
