const OTP = require("./helper/adaotp");
const dotenv = require("dotenv");
dotenv.config();
(async () => {
  const sms = new OTP(process.env.SMS_ADAOTP);
  //   const balance = await sms.GetNumber("11");
  const message = await sms.GetMessage("2714674");
  console.log(message);
  console.log(message.data.data[0]);
  const otp = message.data.data[0].sms;
  console.log(JSON.parse(otp));
})();
