const blibli = require("./helper/index");
const fetch = require("node-fetch");
const { v4: uuidv4 } = require("uuid");
const readline = require("readline-sync");
const fs = require("fs-extra");
const delay = require("delay");
const chalk = require("chalk");
const randstr = (length) =>
  new Promise((resolve, reject) => {
    var text = "";
    var possible = "1234567890";

    for (var i = 0; i < length; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    resolve(text);
  });
const nama = () =>
  new Promise((resolve, reject) => {
    fetch(
      "https://hiyaa.site/data.php?qty=1&apikey=d47d9a94-110f-4672-8851-8b749e0c7e3e",
      {
        method: "GET",
      }
    )
      .then((res) => res.json())
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
(async () => {
  const dataakun = fs.readFileSync("list.txt", "utf8").split("\r\n");
  for (let i in dataakun) {
    await delay(2000);
    const email = dataakun[i].split("|")[0];
    const password = dataakun[i].split("|")[1];
    const UserId = uuidv4();
    const Session = uuidv4();
    const RequestID = uuidv4();
    const DfToken = await randstr(43);
    const request = new blibli(UserId, Session, RequestID, DfToken);
    const indoName = await nama();
    const { result } = indoName;
    const name =
      result[0].firstname.toLowerCase() + result[0].lastname.toLowerCase();
    console.log("CREATE EMAIL " + email);
    const Register = await request.RegisterRequestOTP(
      email,
      password,
      name + (await randstr(4))
    );
    if (Register.result === "true") {
      console.log(chalk.greenBright("Mencoba Register "));
      const chalenge = Register.resultData.challengeToken;
      const MemanggilOtp = await request.RequestOTP(chalenge);
      if (MemanggilOtp.status === "OK") {
        console.log(chalk.greenBright("OTP Dikirim"));
        const otp = readline.question(chalk.yellowBright("Input OTP Email : "));
        const verify = await request.RegisLogin(email, otp, chalenge);
        if (verify.access_token) {
          console.log(chalk.greenBright("Create Succesfully"));
        } else {
          console.log(chalk.redBright("Create Gagal"));
        }
      } else {
        console.log(chalk.redBright("Gagal Kirim OTP "));
      }
    } else {
      console.log(chalk.redBright("Gagal Register "));
      console.log(Register);
    }
  }
})();
