const fetch = require("node-fetch");

const getToken = () =>
  new Promise((resolve, reject) => {
    fetch("http://mekdi.me/getToken", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "accept-language": "en-US,en;q=0.9,id;q=0.8",
        "cache-control": "max-age=0",
        "sec-ch-ua":
          '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "X-Key-Access": "bangsat",
      },
      redirect: "follow",
    })
      .then((res) => res.json())
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
const Refferal = (token) =>
  new Promise((resolve, reject) => {
    fetch("http://mekdi.me/useToken", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
        "accept-language": "en-US,en;q=0.9,id;q=0.8",
        "cache-control": "max-age=0",
        "sec-ch-ua":
          '"Not_A Brand";v="99", "Google Chrome";v="109", "Chromium";v="109"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "document",
        "sec-fetch-mode": "navigate",
        "sec-fetch-site": "none",
        "sec-fetch-user": "?1",
        "upgrade-insecure-requests": "1",
        "X-Key-Access": "bangsat",
      },
      redirect: "follow",
      body: JSON.stringify({
        token: token,
        refCode: "D681453P",
      }),
    })
      .then((res) => res.json())
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
(async () => {
  while (true) {
    try {
      const token = await getToken();
      console.log(token);
      const get = await Refferal(token.token);
      console.log(get);
    } catch (error) {
      console.log(error);
    }
  }
})();
