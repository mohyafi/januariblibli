const blibli = require("./helper/blibliv2");
const fetch = require("node-fetch");
const { v4: uuidv4 } = require("uuid");
const readline = require("readline-sync");
const fs = require("fs-extra");
const delay = require("delay");
const chalk = require("chalk");
const imaps = require("imap-simple");
const { convert } = require("html-to-text");
const { READ_MAIL_CONFIG } = require("./config");
const dayjs = require("dayjs");
const timezone = require("dayjs/plugin/timezone");
const utc = require("dayjs/plugin/utc");
dayjs.extend(timezone);
dayjs.extend(utc);
dayjs.tz.setDefault("Asia/Jakarta");
const randstr = (length) =>
  new Promise((resolve, reject) => {
    var text = "";
    var possible = "1234567890";

    for (var i = 0; i < length; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    resolve(text);
  });
const nama = () =>
  new Promise((resolve, reject) => {
    fetch(
      "https://hiyaa.site/data.php?qty=1&apikey=d47d9a94-110f-4672-8851-8b749e0c7e3e",
      {
        method: "GET",
      }
    )
      .then((res) => res.json())
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
(async () => {
  const dataakun = fs.readFileSync("cekdata.txt", "utf8").split("\r\n");
  for (let i in dataakun) {
    await delay(2000);
    const email = dataakun[i].split("|")[0];
    const password = dataakun[i].split("|")[1];
    const UserId = uuidv4();
    const Session = uuidv4();
    const RequestID = uuidv4();
    const DfToken = await randstr(43);
    const request = new blibli(UserId, Session, RequestID, DfToken);
    console.log(
      chalk.yellowBright(`[ INFO ] `) + chalk.blueBright("Email " + email)
    );
    const Login = await request.Login(email, password);
    const ParseLogin = JSON.stringify(Login);
    if (
      ParseLogin.includes(
        "login using new device is detected, please do challenge otp"
      )
    ) {
      const chalenge = Login.data.challenge.token;
      const MemanggilOtp = await request.RequestOTP(chalenge);
      if (MemanggilOtp.status === "OK") {
        console.log(
          chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("OTP Dikirim")
        );
        await delay(3000);
        const connection = await imaps.connect(READ_MAIL_CONFIG);
        // console.log("CONNECTION SUCCESSFUL", new Date().toString());
        const box = await connection.openBox("INBOX");
        const searchCriteria = ["ALL", ["TO", email]];
        const fetchOptions = {
          bodies: ["HEADER", "TEXT"],
          markSeen: false,
        };
        let parsing;
        do {
          const results = await connection.search(searchCriteria, fetchOptions);
          try {
            let emailText = convert(
              results[results.length - 1]["parts"][1]["body"]
            );
            // console.log(emailText);
            parsing = emailText
              .split("Kode verifikasi: ")[1]
              .split("<=")[0]
              .split(" ")[1];
            // console.log(parsing);
          } catch (error) {
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.redBright("Belum DItemukan")
            );
            try {
              let emailText = convert(results[1]["parts"][1]["body"]);
              // console.log(emailText);
              parsing = emailText
                .split("Kode verifikasi: ")[1]
                .split("<=")[0]
                .split(" ")[1];
              // console.log(parsing);
            } catch (error) {
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.redBright("Belum DItemukan")
              );
              try {
                let emailText = convert(results[0]["parts"][1]["body"]);
                // console.log(emailText);
                parsing = emailText
                  .split("Kode verifikasi: ")[1]
                  .split("<=")[0]
                  .split(" ")[1];
                // console.log(parsing);
              } catch (error) {
                console.log(
                  chalk.yellowBright(`[ INFO ] `) +
                    chalk.redBright("Belum DItemukan")
                );
              }
            }
          }
        } while (!parsing);
        // });
        connection.end();
        const otp = parsing;
        console.log(
          chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("OTP : " + otp)
        );
        let statuspin = "";
        const verify = await request.RegisLogin(email, otp, chalenge);
        if (verify.access_token) {
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright("Login Succesfully")
          );
          const Token = verify.access_token;
          const dataAccount = await request.CeckStatusAccount(Token);
          const saldo = dataAccount.data.wallet.balance;
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright("Saldo Account [ " + saldo + " ]")
          );
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright(
                "Status Pin [ " + dataAccount.data.wallet.pinRegistered + " ]"
              )
          );
          if (!fs.existsSync(`bliblidatatoken`))
            fs.mkdirSync(`bliblidatatoken`);
          fs.appendFileSync(
            `./bliblidatatoken/${email}.json`,
            JSON.stringify({
              token: Token,
              refresh_token: verify.refresh_token,
              userId: UserId,
              sessionId: Session,
              requestId: RequestID,
              saldo: saldo,
              pin: dataAccount.data.wallet.pinRegistered,
              password: process.env.PASSWORD,
              usermail: process.env.EMAIL,
            })
          );
          fs.appendFileSync("datalogintoken.txt", `${email}.json|${saldo}\n`);
        } else {
          console.log(chalk.redBright("Login Gagal"));
        }
      } else {
        console.log(chalk.redBright("Gagal Kirim OTP "));
      }
    } else {
      console.log(chalk.redBright(ParseLogin));
    }
  }
})();
