const blibli = require("./helper/blibliv2");
const fetch = require("node-fetch");
const { v4: uuidv4 } = require("uuid");
const readline = require("readline-sync");
const fs = require("fs-extra");
const delay = require("delay");
const chalk = require("chalk");
const imaps = require("imap-simple");
const { convert } = require("html-to-text");
const { READ_MAIL_CONFIG } = require("./config");
const randstr = (length) =>
  new Promise((resolve, reject) => {
    var text = "";
    var possible = "1234567890";

    for (var i = 0; i < length; i++)
      text += possible.charAt(Math.floor(Math.random() * possible.length));

    resolve(text);
  });
const nama = () =>
  new Promise((resolve, reject) => {
    fetch(
      "https://hiyaa.site/data.php?qty=1&apikey=d47d9a94-110f-4672-8851-8b749e0c7e3e",
      {
        method: "GET",
      }
    )
      .then((res) => res.json())
      .then((res) => {
        resolve(res);
      })
      .catch((err) => {
        reject(err);
      });
  });
(async () => {
  const dataakun = fs.readFileSync("list3.txt", "utf8").split("\r\n");
  for (let i in dataakun) {
    await delay(2000);
    const datayahoo = dataakun[i].split("|")[0];
    // console.log(datayahoo);
    const cekdata = fs.readFileSync(`./bliblidatatoken/${datayahoo}`, "utf8");
    const dataaccount = JSON.parse(cekdata);
    // console.log(JSON.parse(cekdata));
    const UserId = dataaccount.userId;
    const Session = dataaccount.sessionId;
    const RequestID = dataaccount.requestId;
    const DfToken = await randstr(43);
    const request = new blibli(UserId, Session, RequestID, DfToken);
    console.log(
      chalk.yellowBright(`[ INFO ] `) +
        chalk.blueBright("dataLogin " + datayahoo)
    );
    const Token = dataaccount.token;
    const dataAccount = await request.CeckStatusAccount(Token);
    const saldo = dataAccount.data.wallet.balance;
    // console.log(saldo);
    console.log(
      chalk.yellowBright(`[ INFO ] `) +
        chalk.greenBright("Saldo Account [ " + saldo + " ]")
    );
    const datapaper = fs.readFileSync("listkode3.txt", "utf8").split("\r\n");
    const PaperId = datapaper[i];
    console.log(
      chalk.yellowBright(`[ INFO ] `) +
        chalk.yellowBright("Kode PaperId [ " + PaperId + " ]")
    );
    const Cart = await request.DeleteCartDigital(Token);
    if (Cart.status === "OK") {
      console.log(
        chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("Try Add Cart ")
      );
      const Checkout = await request.InputIdPaper(Token, PaperId);
      if (Checkout.status === "OK") {
        console.log(
          chalk.yellowBright(`[ INFO ] `) +
            chalk.greenBright("Try Check Add Cart ")
        );
        const CekCheckout = await request.CekCartDigital(Token);
        if (CekCheckout.status === "OK") {
          console.log(
            chalk.yellowBright(`[ INFO ] `) + chalk.greenBright("Get Payment ")
          );
          console.log(
            chalk.yellowBright(`[ INFO ] `) +
              chalk.greenBright("Payment Processing Cek You Account Jenius ")
          );
          const Pay = await request.PaymentWallet(Token);
          if (Pay.status === "OK") {
            const Final = await request.PaymentFinalQRIS(Token);
            const IdPesnanan = Final.data.orderId;
            const ApplyPin = await request.PaymentWalletPin(
              Token,
              IdPesnanan,
              "312001"
            );
            //   console.log(ApplyPin);
            let CekPesananStatus;
            let Validasi;
            do {
              CekPesananStatus = await request.CekStatusPesanan(
                Token,
                IdPesnanan
              );
              Validasi = JSON.stringify(CekPesananStatus);
              await delay(3000);
              console.log(
                chalk.yellowBright(`[ INFO ] `) +
                  chalk.redBright("Tagihan Belum Dibayar")
              );
            } while (!Validasi.includes("TRANSACTION_SUCCESS"));
            console.log(
              chalk.yellowBright(`[ INFO ] `) +
                chalk.greenBright(
                  "Status [ " +
                    CekPesananStatus.data[0].transactionStatus +
                    " ]"
                )
            );
          } else {
            console.log(Pay);
          }
        } else {
          console.log(CekCheckout);
        }
      } else {
        console.log(Checkout);
      }
    } else {
      console.log(Cart);
    }
  }
})();
