const fetch = require("node-fetch");

class TIKET {
  async CheckingEMail(Email) {
    const request = fetch(
      "https://www.tiket.com/ms-gateway/tix-member-core/v2/auth/onefield/" +
        Email,
      {
        headers: {
          Host: "www.tiket.com",
          "Sec-Ch-Ua": '"Chromium";v="113", "Not-A.Brand";v="24"',
          "Sec-Ch-Ua-Platform": '"Windows"',
          "Sec-Ch-Ua-Mobile": "?0",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.127 Safari/537.36",
          Lang: "id",
          "X-Currency": "IDR",
          "X-Audience": "tiket.com",
          "X-Cookie-Session-V2": "true",
          Accept: "*/*",
          "Sec-Fetch-Site": "same-origin",
          "Sec-Fetch-Mode": "cors",
          "Sec-Fetch-Dest": "empty",
          Referer: "https://www.tiket.com/login?ref=https://www.tiket.com/",
          "Accept-Encoding": "gzip, deflate",
          "Accept-Language": "en-US,en;q=0.9",
          Cookie:
            "session_access_token=eyJraWQiOiJDalFpd2tlRjFLUHdhb3VNa0VWSWQ0QUMxX0ZueWVBSCJ9.eyJhdWQiOiJ0aWtldC5jb20iLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcwMTUyMDc2MX0.weqRNV3ULXKEF7AQLyse8f6Y1KXvHyS0zkKe-vPZAxi3OQM9zMDc3j9DKrtPXiEO; session_refresh_token=eyJraWQiOiJlbTR3UEZEUlZLTkZlVW80dzhDR1ZpYTJndElqc3NfaCJ9.eyJhdWQiOiJ0aWtldC5jb20vcnQiLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcxNzMwMDc2MX0.Y7zrfsvCWavlJ62LtatclYpGoPs-Swqp-JeEQ0JbrCpcT2TnqzOyS4D6FqRN19ZD; __cf_bm=9OsihpIRTQGRcHDrnPNw8tXIwZnNxOEk5Nxmv3uydFc-1685740761-0-AQAJG/PVM4jb5fYsv9z36ZOMQCpCDm21OsGRG+CsJaYQ690XfNuY6qqJSSxk/gCgtru1cm2XjXV1K9zl/oN6oOfpN3uNnL97HonYEWKkuQsH; _cfuvid=HbUYKbi6BBZ4VKFrp0SKeAbdCYwU1kQ1YUAQmuTDvVs-1685740761384-0-604800000; userlang=id; tiket_currency=IDR; _gid=GA1.2.644208705.1685740762; _gat_UA-22317351-1=1; _gcl_au=1.1.1663384892.1685740763; _tix_logger_correlation_id=2fc5839a-3dc4-4982-8eb8-692167b1baed; PHPSESSID=a51375da-d4ae-49ea-ae6c-9e32066d5914; _ga=GA1.1.864915775.1685740762; _ga_7H6ZDP2ZXG=GS1.1.1685740657.2.1.1685740772.16.0.0; amp_b34eb5=bf7dc9d3e4254c38e597e8df204c134c...1h1uvlcgo.1h1uvlood.3.a.d",
        },
      }
    ).then((res) => res.json());
    return await request;
  }
  async RequestOtp(number) {
    const request = fetch(
      "https://www.tiket.com/ms-gateway/tix-members-core/otp/v2/generate/GUEST_VERIFY_PHONE",
      {
        headers: {
          Host: "www.tiket.com",
          "Accept-Encoding": "gzip, deflate",
          Accept: "*/*",
          "Accept-Language": "en-US;q=0.9,en;q=0.8",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.127 Safari/537.36",
          Connection: "close",
          "Cache-Control": "max-age=0",
          Cookie:
            "session_access_token=eyJraWQiOiJDalFpd2tlRjFLUHdhb3VNa0VWSWQ0QUMxX0ZueWVBSCJ9.eyJhdWQiOiJ0aWtldC5jb20iLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcwMTUyMDc2MX0.weqRNV3ULXKEF7AQLyse8f6Y1KXvHyS0zkKe-vPZAxi3OQM9zMDc3j9DKrtPXiEO; session_refresh_token=eyJraWQiOiJlbTR3UEZEUlZLTkZlVW80dzhDR1ZpYTJndElqc3NfaCJ9.eyJhdWQiOiJ0aWtldC5jb20vcnQiLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcxNzMwMDc2MX0.Y7zrfsvCWavlJ62LtatclYpGoPs-Swqp-JeEQ0JbrCpcT2TnqzOyS4D6FqRN19ZD; __cf_bm=9OsihpIRTQGRcHDrnPNw8tXIwZnNxOEk5Nxmv3uydFc-1685740761-0-AQAJG/PVM4jb5fYsv9z36ZOMQCpCDm21OsGRG+CsJaYQ690XfNuY6qqJSSxk/gCgtru1cm2XjXV1K9zl/oN6oOfpN3uNnL97HonYEWKkuQsH; _cfuvid=HbUYKbi6BBZ4VKFrp0SKeAbdCYwU1kQ1YUAQmuTDvVs-1685740761384-0-604800000; userlang=id; tiket_currency=IDR; _gid=GA1.2.644208705.1685740762; _gat_UA-22317351-1=1; _gcl_au=1.1.1663384892.1685740763; _tix_logger_correlation_id=2fc5839a-3dc4-4982-8eb8-692167b1baed; PHPSESSID=a51375da-d4ae-49ea-ae6c-9e32066d5914; _ga=GA1.1.864915775.1685740762; _ga_7H6ZDP2ZXG=GS1.1.1685740657.2.1.1685740772.16.0.0; amp_b34eb5=bf7dc9d3e4254c38e597e8df204c134c...1h1uvlcgo.1h1uvlood.3.a.d",
        },
        method: "POST",
        body: JSON.stringify({
          ignoreRecipient: false,
          recipient: "+" + number,
          magicLinkAdditionalParameter: "",
        }),
      }
    ).then((res) => res.json());
    return await request;
  }
  async CheckingOtp(trxid, otp) {
    const request = fetch(
      "https://www.tiket.com/ms-gateway/tix-members-core/otp/v2/verify",
      {
        headers: {
          Host: "www.tiket.com",
          "Accept-Encoding": "gzip, deflate",
          Accept: "*/*",
          "Accept-Language": "en-US;q=0.9,en;q=0.8",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.127 Safari/537.36",
          Connection: "close",
          "Cache-Control": "max-age=0",
          Cookie:
            "session_access_token=eyJraWQiOiJDalFpd2tlRjFLUHdhb3VNa0VWSWQ0QUMxX0ZueWVBSCJ9.eyJhdWQiOiJ0aWtldC5jb20iLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcwMTUyMDc2MX0.weqRNV3ULXKEF7AQLyse8f6Y1KXvHyS0zkKe-vPZAxi3OQM9zMDc3j9DKrtPXiEO; session_refresh_token=eyJraWQiOiJlbTR3UEZEUlZLTkZlVW80dzhDR1ZpYTJndElqc3NfaCJ9.eyJhdWQiOiJ0aWtldC5jb20vcnQiLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcxNzMwMDc2MX0.Y7zrfsvCWavlJ62LtatclYpGoPs-Swqp-JeEQ0JbrCpcT2TnqzOyS4D6FqRN19ZD; __cf_bm=9OsihpIRTQGRcHDrnPNw8tXIwZnNxOEk5Nxmv3uydFc-1685740761-0-AQAJG/PVM4jb5fYsv9z36ZOMQCpCDm21OsGRG+CsJaYQ690XfNuY6qqJSSxk/gCgtru1cm2XjXV1K9zl/oN6oOfpN3uNnL97HonYEWKkuQsH; _cfuvid=HbUYKbi6BBZ4VKFrp0SKeAbdCYwU1kQ1YUAQmuTDvVs-1685740761384-0-604800000; userlang=id; tiket_currency=IDR; _gid=GA1.2.644208705.1685740762; _gat_UA-22317351-1=1; _gcl_au=1.1.1663384892.1685740763; _tix_logger_correlation_id=2fc5839a-3dc4-4982-8eb8-692167b1baed; PHPSESSID=a51375da-d4ae-49ea-ae6c-9e32066d5914; _ga=GA1.1.864915775.1685740762; _ga_7H6ZDP2ZXG=GS1.1.1685740657.2.1.1685740772.16.0.0; amp_b34eb5=bf7dc9d3e4254c38e597e8df204c134c...1h1uvlcgo.1h1uvlood.3.a.d",
        },
        method: "POST",
        body: JSON.stringify({
          token: otp,
          trxId: trxid,
        }),
      }
    ).then((res) => res.json());
    return await request;
  }
  async Register(email, name, number, otp, trxId, password, uniqueId) {
    const request = fetch(
      "https://www.tiket.com/ms-gateway/tix-member-core/v2/auth/v3/register",
      {
        method: "POST",
        headers: {
          Host: "www.tiket.com",
          "Content-Length": "411",
          "Sec-Ch-Ua": '"Chromium";v="113", "Not-A.Brand";v="24"',
          "X-Cookie-Session-V2": "true",
          "Sec-Ch-Ua-Mobile": "?0",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.127 Safari/537.36",
          "Content-Type": "application/json",
          Lang: "id",
          "X-Currency": "IDR",
          Tixsession: "8dbc5f7e-016a-4bcb-9805-69d767e95fe2",
          "X-Audience": "tiket.com",
          "Sec-Ch-Ua-Platform": '"Windows"',
          Accept: "*/*",
          Origin: "https://www.tiket.com",
          "Sec-Fetch-Site": "same-origin",
          "Sec-Fetch-Mode": "cors",
          "Sec-Fetch-Dest": "empty",
          "Accept-Encoding": "gzip, deflate",
          "Accept-Language": "en-US,en;q=0.9",
          Cookie:
            "session_access_token=eyJraWQiOiJDalFpd2tlRjFLUHdhb3VNa0VWSWQ0QUMxX0ZueWVBSCJ9.eyJhdWQiOiJ0aWtldC5jb20iLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcwMTUyMDc2MX0.weqRNV3ULXKEF7AQLyse8f6Y1KXvHyS0zkKe-vPZAxi3OQM9zMDc3j9DKrtPXiEO; session_refresh_token=eyJraWQiOiJlbTR3UEZEUlZLTkZlVW80dzhDR1ZpYTJndElqc3NfaCJ9.eyJhdWQiOiJ0aWtldC5jb20vcnQiLCJzdWIiOiI2NDdhNWNkOTY2NDgzODQ2ZjI1YzA2YzAiLCJuYmYiOjE2ODU3NDA3NjEsImlzcyI6Imh0dHBzOi8vd3d3LnRpa2V0LmNvbSIsImV4cCI6MTcxNzMwMDc2MX0.Y7zrfsvCWavlJ62LtatclYpGoPs-Swqp-JeEQ0JbrCpcT2TnqzOyS4D6FqRN19ZD; __cf_bm=9OsihpIRTQGRcHDrnPNw8tXIwZnNxOEk5Nxmv3uydFc-1685740761-0-AQAJG/PVM4jb5fYsv9z36ZOMQCpCDm21OsGRG+CsJaYQ690XfNuY6qqJSSxk/gCgtru1cm2XjXV1K9zl/oN6oOfpN3uNnL97HonYEWKkuQsH; _cfuvid=HbUYKbi6BBZ4VKFrp0SKeAbdCYwU1kQ1YUAQmuTDvVs-1685740761384-0-604800000; userlang=id; tiket_currency=IDR; _gid=GA1.2.644208705.1685740762; _gcl_au=1.1.1663384892.1685740763; tiketDeviceId=3e680549-36cc-45f6-ab91-79b55a; _tix_logger_correlation_id=e66dd852-4e40-451c-996f-19ddbcdaf84e; PHPSESSID=8dbc5f7e-016a-4bcb-9805-69d767e95fe2; _ga=GA1.2.864915775.1685740762; _gat_UA-22317351-1=1; amp_b34eb5=bf7dc9d3e4254c38e597e8df204c134c...1h1uvlcgo.1h1uvnj86.5.f.k; _ga_7H6ZDP2ZXG=GS1.1.1685740657.2.1.1685740858.36.0.0",
        },
        body: JSON.stringify({
          email: email,
          fullName: name,
          fullPhoneNumber: "+" + number,
          otpTokenEmail: null,
          otpTokenPhone: otp,
          otpTrxIdEmail: null,
          otpTrxIdPhone: trxId,
          password: password,
          referralToken: null,
          referrer: null,
          registerSource: "TIKET_EMAIL",
          deviceIdentity: {
            appVersion: null,
            osVersion: "Chrome",
            uniqueId: uniqueId,
          },
        }),
      }
    ).then((res) => res.json());
    return await request;
  }
  async GetIdUpdate(accestoken, refreshtoken) {
    const request = fetch("https://gql.tiket.com/", {
      headers: {
        accept: "*/*",
        "accept-language": "en-US,en;q=0.9",
        channelid: "DESKTOP",
        "content-type": "application/json",
        lang: "id",
        newsession: "true",
        platform: "WEB",
        "sec-ch-ua":
          '"Google Chrome";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        cookie: `tiket_currency=IDR; userlang=id; __cf_bm=ru9EzmmGN_HTwr5FmTCq505XPBQLGkVl5_VzrgF19kE-1685767069-0-AXE++l8vYIJIO3t+DYp+fEbqhuoRi2StuwxQv9g6fO1Ty0AQWGR46gI5laaRYIpNsBaYLdahAbqmykChOassY5zWjba9v1KOiAUk4OxyIZBK; _cfuvid=TxACN1lDRJo6fE84O5qHssQf_MCplZoUiGc_cvUroyg-1685767069349-0-604800000; PHPSESSID=c969497c-bbdd-4df8-9dee-3a0e37d32105; _gid=GA1.2.78858891.1685767080; _gcl_au=1.1.2053550636.1685767083; _fbp=fb.1.1685767084691.1984445698; _tt_enable_cookie=1; _ttp=BAcHZ2oNuoi4K1cVEqLXQW7RApW; device[type]=x; tsct=e29d855488277ff1e54435bd5c1b4590; partner=%28default%29; tiketDeviceId=4827d655-6836-41bb-b3da-dfdf95; _gat_UA-22317351-1=1; session_access_token=${accestoken}; session_refresh_token=${refreshtoken}; _tix_logger_correlation_id=485592e7-36c4-4f02-8f33-137d9e4af1e4; ab.storage.userId.3a9cb405-9ac0-4c31-a856-3183ef998519=%7B%22g%22%3A%2267516645%22%2C%22c%22%3A1685767162724%2C%22l%22%3A1685767162732%7D; ab.storage.deviceId.3a9cb405-9ac0-4c31-a856-3183ef998519=%7B%22g%22%3A%22f5f2036e-604a-3140-fa77-4edf51254d96%22%2C%22c%22%3A1685767162734%2C%22l%22%3A1685767162734%7D; _ga=GA1.2.521230913.1685767080; ab.storage.sessionId.3a9cb405-9ac0-4c31-a856-3183ef998519=%7B%22g%22%3A%22e326378f-c964-2b57-7746-baba35b29d17%22%2C%22e%22%3A1685768993361%2C%22c%22%3A1685767162730%2C%22l%22%3A1685767193361%7D; _ga_7H6ZDP2ZXG=GS1.1.1685767079.1.1.1685767193.7.0.0; amp_b34eb5=96ad4b55f1e39267587979c8f58438a8.Njc1MTY2NDU=..1h1vm5h39.1h1vos3en.m.27.2t`,
        Referer: "https://www.tiket.com/myaccount/smart_traveler",
        "Referrer-Policy": "no-referrer-when-downgrade",
      },
      body: '[{"operationName":"profileList","variables":{"memberType":"B2C","sortType":"","showStatus":true},"query":"query profileList($memberType: String, $sortType: String, $showStatus: Boolean) {\\n  profileList(memberType: $memberType, sortType: $sortType, showStatus: $showStatus) {\\n    code\\n    message\\n    errors\\n    data {\\n      id\\n      accountId\\n      isPrimary\\n      accountSalutationName\\n      accountFirstName\\n      accountLastName\\n      accountGender\\n      accountPhone\\n      accountPhoneCode\\n      accountBirthdate\\n      accountNationalityCode\\n      accountEmail\\n      emergencyContactName\\n      emergencyContactNumber\\n      emergencyCountryPhoneCode\\n      identityType\\n      identityNumber\\n      identityFullname\\n      passportNumber\\n      passportExpiryDate\\n      passportIssuedDate\\n      passportIssuingCountry\\n      ages\\n      isNew\\n      createdTimestamp\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}]',
      method: "POST",
    }).then((res) => res.json());
    return await request;
  }
  async Update(email, name, number, accountId, accestoken, refreshtoken) {
    // const data = {"query":"mutation putProfileUpdateMutation($accountBirthdate: String, $accountEmail: String, $accountFirstName: String, $accountGender: String, $accountLastName: String, $accountNationalityCode: String, $accountPhone: String, $accountPhoneCode: String, $accountSalutationName: String, $adminType: String, $b2BType: String, $emergencyContactName: String, $emergencyContactNumber: String, $emergencyCountryPhoneCode: String, $id: Int, $identityFullname: String, $identityNumber: String, $identityType: String, $isPrimary: Boolean, $passportExpiryDate: String, $passportIssuedDate: String, $passportIssuingCountry: String, $passportNumber: String, $memberType: String) {\n  profileUpdate(accountBirthdate: $accountBirthdate, accountEmail: $accountEmail, accountFirstName: $accountFirstName, accountGender: $accountGender, accountLastName: $accountLastName, accountNationalityCode: $accountNationalityCode, accountPhone: $accountPhone, accountPhoneCode: $accountPhoneCode, accountSalutationName: $accountSalutationName, adminType: $adminType, b2BType: $b2BType, emergencyContactName: $emergencyContactName, emergencyContactNumber: $emergencyContactNumber, emergencyCountryPhoneCode: $emergencyCountryPhoneCode, id: $id, identityFullname: $identityFullname, identityNumber: $identityNumber, identityType: $identityType, isPrimary: $isPrimary, passportExpiryDate: $passportExpiryDate, passportIssuedDate: $passportIssuedDate, passportIssuingCountry: $passportIssuingCountry, passportNumber: $passportNumber, memberType: $memberType) {\n    code\n    message\n    errors\n    data {\n      id\n      accountId\n      isPrimary\n      accountSalutationName\n      accountFirstName\n      accountLastName\n      ages\n      __typename\n    }\n    __typename\n  }\n}\n"}
    const request = fetch("https://gql.tiket.com/", {
      headers: {
        accept: "*/*",
        "accept-language": "en-US,en;q=0.9",
        channelid: "DESKTOP",
        "content-type": "application/json",
        deviceid: "96ad4b55f1e30267587979c8f58438a8",
        lang: "id",
        newsession: "true",
        platform: "dweb",
        "sec-ch-ua":
          '"Google Chrome";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        tiketsessionid: "8dbc5f7e-016a-4bcb-9805-69d767e95fe2",
        cookie: `__cf_bm=2dTBtlDm81h1W5CZ0nOPNo8aKl.QL2YbmSfkOIZ6ePI-1685740963-0-AaI4esIra/xp1FAEKMq/K0cv+yvvyW64p4qwoSgW1g7tZb4Kt839dJ0X+sQa8ARl6nnmMWuFBl5iYdLuKPuNcp1aqNcME63S5/fpZJ5JcHUv; _cfuvid=R.A1L.sM4mN1eTjCu7EyOQYk7jDvbuAXrlB1fUqKpmU-1685740963389-0-604800000; userlang=id; tiket_currency=IDR; _gid=GA1.2.1267520805.1685740964; _gcl_au=1.1.1388277606.1685740964; _fbp=fb.1.1685740966270.357912296; _tt_enable_cookie=1; _ttp=g9i0z-j-uDSk9wBjjV1ZchWPb8p; PHPSESSID=c5020256-acbe-4da9-9780-341eec1fc18f; tiketDeviceId=86af5bb3-5a7c-4850-90f6-6813da; session_access_token=${accestoken}; session_refresh_token=${refreshtoken}; ab.storage.userId.3a9cb405-9ac0-4c31-a856-3183ef998519=%7B%22g%22%3A%2267501441%22%2C%22c%22%3A1685741066610%2C%22l%22%3A1685741066612%7D; ab.storage.deviceId.3a9cb405-9ac0-4c31-a856-3183ef998519=%7B%22g%22%3A%22d1de34fc-d6d5-87a5-f638-91e213a71066%22%2C%22c%22%3A1685741066614%2C%22l%22%3A1685741066614%7D; _tix_logger_correlation_id=6220ec88-3a77-41fa-9ed6-52146f0d9d25; ab.storage.sessionId.3a9cb405-9ac0-4c31-a856-3183ef998519=%7B%22g%22%3A%22b72c3afe-2fe9-11b4-7a08-f9c5d58a5700%22%2C%22e%22%3A1685742872705%2C%22c%22%3A1685741066612%2C%22l%22%3A1685741072705%7D; amp_b34eb5=96ad4b55f1e39267587979c8f58438a8.Njc1MDE0NDE=..1h1uvri5e.1h1uvv6cg.a.q.14; _ga_7H6ZDP2ZXG=GS1.1.1685740963.1.1.1685741083.6.0.0; _ga=GA1.1.1859722174.1685740964`,
        Referer: "https://www.tiket.com/myaccount/smart_traveler",
        "Referrer-Policy": "no-referrer-when-downgrade",
      },
      body: `[{"operationName":"putProfileUpdateMutation","variables":{"accountBirthdate":"2000-06-08","accountEmail":"${email}","accountFirstName":"${name}","accountGender":"F","accountLastName":"${name}","accountNationalityCode":"ID","accountPhone":"${number}","accountPhoneCode":"+62","accountSalutationName":"TUAN","adminType":null,"b2BType":null,"emergencyContactName":"dede","emergencyContactNumber":"896787685745","emergencyCountryPhoneCode":"+62","id":${accountId},"identityFullname":"","identityNumber":"3322057689034500","identityType":"","isPrimary":true,"passportExpiryDate":"","passportIssuedDate":"","passportIssuingCountry":"","passportNumber":"","memberType":"B2C"},"query":"mutation putProfileUpdateMutation($accountBirthdate: String, $accountEmail: String, $accountFirstName: String, $accountGender: String, $accountLastName: String, $accountNationalityCode: String, $accountPhone: String, $accountPhoneCode: String, $accountSalutationName: String, $adminType: String, $b2BType: String, $emergencyContactName: String, $emergencyContactNumber: String, $emergencyCountryPhoneCode: String, $id: Int, $identityFullname: String, $identityNumber: String, $identityType: String, $isPrimary: Boolean, $passportExpiryDate: String, $passportIssuedDate: String, $passportIssuingCountry: String, $passportNumber: String, $memberType: String) {\\n  profileUpdate(accountBirthdate: $accountBirthdate, accountEmail: $accountEmail, accountFirstName: $accountFirstName, accountGender: $accountGender, accountLastName: $accountLastName, accountNationalityCode: $accountNationalityCode, accountPhone: $accountPhone, accountPhoneCode: $accountPhoneCode, accountSalutationName: $accountSalutationName, adminType: $adminType, b2BType: $b2BType, emergencyContactName: $emergencyContactName, emergencyContactNumber: $emergencyContactNumber, emergencyCountryPhoneCode: $emergencyCountryPhoneCode, id: $id, identityFullname: $identityFullname, identityNumber: $identityNumber, identityType: $identityType, isPrimary: $isPrimary, passportExpiryDate: $passportExpiryDate, passportIssuedDate: $passportIssuedDate, passportIssuingCountry: $passportIssuingCountry, passportNumber: $passportNumber, memberType: $memberType) {\\n    code\\n    message\\n    errors\\n    data {\\n      id\\n      accountId\\n      isPrimary\\n      accountSalutationName\\n      accountFirstName\\n      accountLastName\\n      ages\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n"}]`,
      method: "POST",
    }).then((res) => res.json());
    return await request;
  }
  async Exchange(cookie) {
    const request = fetch(
      "https://www.bliblitiketrewards.com/api/deals/redemption/_exchange-voucher",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9",
          "content-type": "application/json",
          "sec-ch-ua":
            '"Google Chrome";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-origin",
          cookie: cookie,
          Referer:
            "https://www.bliblitiketrewards.com/member/voucher-deals/6475bb3e8681c608390c4e1a",
          "Referrer-Policy": "same-origin",
        },
        body: '{"productSku":"6475bb3e8681c608390c4e1a"}',
        method: "POST",
      }
    ).then((res) => res.json());
    return await request;
  }
  async Redem(cookie, id) {
    const request = fetch(
      "https://www.bliblitiketrewards.com/api/deals/my-voucher/_redeem",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9",
          "content-type": "application/json",
          "sec-ch-ua":
            '"Google Chrome";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-origin",
          cookie: cookie,
          Referer:
            "https://www.bliblitiketrewards.com/member/my-vouchers/" + id,
          "Referrer-Policy": "same-origin",
        },
        body: JSON.stringify({ orderId: id }),
        method: "POST",
      }
    ).then((res) => res.json());
    return await request;
  }
  async GenerateToken(email, accestoken, refreshtoken) {
    const request = fetch(
      "https://www.tiket.com/ms-gateway/tix-loyalty-core/ulp/generate-token",
      {
        method: "POST",
        headers: {
          Host: "www.tiket.com",
          "Content-Length": "0",
          "Sec-Ch-Ua": '"Chromium";v="113", "Not-A.Brand";v="24"',
          Tracestate:
            "541344@nr=0-1-541344-749335357-a1919a3779ea832d----1685766406947",
          "X-Store-Id": "TIKETCOM",
          Authorization: `Bearer ${accestoken}`,
          Newrelic:
            "eyJ2IjpbMCwxXSwiZCI6eyJ0eSI6IkJyb3dzZXIiLCJhYyI6IjU0MTM0NCIsImFwIjoiNzQ5MzM1MzU3IiwiaWQiOiJhMTkxOWEzNzc5ZWE4MzJkIiwidHIiOiIyZjM1YzkwNWM2ZGIzNTc1MDUzMGVmY2ViNmYxYjcwMCIsInRpIjoxNjg1NzY2NDA2OTQ3fX0=",
          "X-Account-Id": "52779302",
          Lang: "id",
          "X-Request-Id": "8b9c3425-283v-42c9-ba3c-f6cmt9kf833d",
          "Sec-Ch-Ua-Platform": '"Windows"',
          "X-Channel-Id": "WEB",
          Tixapi: "1",
          Traceparent:
            "00-2f35c905c6db35750530efceb6f1b700-a1919a3779ea832d-01",
          Source: "desktop",
          "X-Username": email,
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.5672.127 Safari/537.36",
          "Sec-Ch-Ua-Mobile": "?0",
          "Content-Type": "application/x-www-form-urlencoded",
          "X-Service-Id": "gateway",
          "X-Cookie-Session-V2": "true",
          Accept: "*/*",
          Origin: "https://www.tiket.com",
          "Sec-Fetch-Site": "same-origin",
          "Sec-Fetch-Mode": "cors",
          "Sec-Fetch-Dest": "empty",
          Referer: "https://www.tiket.com/rewards",
          "Accept-Encoding": "gzip, deflate",
          "Accept-Language": "en-US,en;q=0.9",
          Cookie: `session_access_token=${accestoken}; session_refresh_token=${refreshtoken}; userlang=id; tiket_currency=IDR; __cf_bm=V__EblMefe8ezx3uOsTpwWSbLk0RtkDsb5v91IIKJxY-1685765901-0-Abz9qxCxiIXJQgDtd4yaCTUBgXFIOUdaUK18loBmd1TlAd0fbRvKI79UfA1E6IkJAVZYxSC9+a7x8VFyS8oBsgTVb7S1JcwfYQBQyQSy9QQ4; _cfuvid=T25tSi6sFWwhWj.2T3GqUyFloN5Fp6C0JnOS3uulwLE-1685765901673-0-604800000; PHPSESSID=37b63310-fdf7-4fef-bec0-9e6b3a5036d6; _gid=GA1.2.1858476452.1685765917; tiketDeviceId=ad02feb0-29ea-43bc-9c4e-b8794a; _gcl_au=1.1.572823087.1685765948; _fbp=fb.1.1685765949279.1317878046; _ga=GA1.2.18509454.1685765917; _tix_logger_correlation_id=6954ca61-39c1-49c1-896e-790db8961426; _ga_7H6ZDP2ZXG=GS1.1.1685765916.1.1.1685766323.49.0.0; usercurrency=IDR; EXPRESS-SESSION=s%3A4eY7VU54sQFjUxhzqHjg_KkCxZf8SgWM.BGXs8RmCfbwIcoquFdA5b2wa7lHZjDzKnzMFMH3mdqs; amp_b34eb5=bf7dc9d3e4254c38e597e8df204c134c.NTI3NzkzMDI=..1h1vnl27j.1h1vo3qgp.b.1c.1n`,
        },
      }
    ).then((res) => res.json());
    return await request;
  }
  async GnerateNewToken(accountId, accestoken, bearer) {
    const request = fetch(
      "https://www.bliblitiketrewards.com/api/token/_exchange",
      {
        headers: {
          accept: "*/*",
          "accept-language": "en-US,en;q=0.9",
          authorization: "Bearer " + bearer,
          "content-type": "application/json",
          "sec-ch-ua":
            '"Google Chrome";v="113", "Chromium";v="113", "Not-A.Brand";v="24"',
          "sec-ch-ua-mobile": "?0",
          "sec-ch-ua-platform": '"Windows"',
          "sec-fetch-dest": "empty",
          "sec-fetch-mode": "cors",
          "sec-fetch-site": "same-origin",
          cookie: `ULP_Partner_Member_Id=${accountId}; ULP_Access_Token=${accestoken}`,
          "Referrer-Policy": "same-origin",
        },
        body: null,
        method: "POST",
      }
    ).then((res) => res.json());
    return await request;
  }
}
module.exports = TIKET;
