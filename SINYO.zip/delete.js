const imaps = require("imap-simple");
const { convert } = require("html-to-text");
const { READ_MAIL_CONFIG } = require("./config");
console.log(READ_MAIL_CONFIG);
(async () => {
  while (true) {
    try {
      const connection = await imaps.connect(READ_MAIL_CONFIG);
      console.log(connection);
      // console.log("CONNECTION SUCCESSFUL", new Date().toString());
      const box = await connection.openBox("INBOX");
      console.log(box);
      if (box.messages.total === 0) {
        console.log("Done Clear Message All");
        connection.end();
        break;
      }
      const searchCriteria = ["ALL"];
      const fetchOptions = {
        bodies: ["HEADER", "TEXT"],
        markSeen: false,
      };

      const results = await connection.delBox("INBOX");
      console.log(results);
    } catch (error) {
      // console.log(error);
      console.log("Mencoba Menhgapus Lagi ");
    }
  }
})();
