const dotenv = require("dotenv");
dotenv.config();
module.exports.READ_MAIL_CONFIG = {
  imap: {
    password: process.env.PASSWORD,
    user: process.env.EMAIL,
    host: "imap.mail.yahoo.com",
    port: 993,
    authTimeout: 10000,
    tls: true,
    tlsOptions: { rejectUnauthorized: false },
  },
};
module.exports.SEND_MAIL_CONFIG = {
  service: "yahoo",
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASSWORD,
  },
};
